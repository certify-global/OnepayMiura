Part No:		M000-EMVL2CL-V1-23
Description:	Miura Contactless support library
Date:			2020-10-08

For more information please see release note: M000-EMVL2CL-V1-23-RN.pdf

