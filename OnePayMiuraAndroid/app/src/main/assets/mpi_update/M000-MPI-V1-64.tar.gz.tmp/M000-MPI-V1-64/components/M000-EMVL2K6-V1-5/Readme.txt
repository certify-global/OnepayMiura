Part No:		M000-EMVL2K6-V1-5
Description:	Miura Discover DPAS Connect Contactless Level 2 kernel
Date:			2022-03-03

For more information please see release note: M000-EMVL2K6-V1-5-RN.pdf
