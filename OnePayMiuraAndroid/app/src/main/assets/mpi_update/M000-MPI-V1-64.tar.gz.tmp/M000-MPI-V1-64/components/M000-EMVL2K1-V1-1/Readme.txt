Part No:		M000-EMVL2K1-V1-1
Description:	Miura Wave 2(Visa AP) Contactless Level 2 kernel
Date:			2016-06-21

For more information please see release note: M000-EMVL2K1-V1-1-RN.pdf
