Part No:		M000-EMVL2K5-V1-5
Description:	Miura Discover DPAS Connect Contactless Level 2 kernel
Date:			2021-10-12

For more information please see release note: M000-EMVL2K5-V1-2-RN.pdf
