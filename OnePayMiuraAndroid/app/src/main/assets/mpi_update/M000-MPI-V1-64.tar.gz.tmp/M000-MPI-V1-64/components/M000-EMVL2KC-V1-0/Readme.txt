Part No:		M000-EMVL2KC-V1-0
Description:	Miura Interac Contactless Level 2 kernel
Date:			2019-04-08

For more information please see release note: M000-EMVL2KC-V1-0-RN.pdf
