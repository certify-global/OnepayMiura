Part No:		M000-EMVL2K4-V1-5
Description:	Miura AmEx Contactless Level 2 kernel
Date:			2015-10-08

For more information please see release note: M000-EMVL2K4-V1-5-RN.pdf