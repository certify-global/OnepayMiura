Part No:		M000-EMVL2KB-V1-2
Description:	Miura Gemalto Pure Contactless Level 2 kernel
Date:			2020-12-18

For more information please see release note: M000-EMVL2KB-V1-2-RN.pdf
