Part No:		M000-EMVL2L-V3-10
Description:	Miura EMV Level 2 support library
Date:			2020-11-11

For more information please see release note: M000-EMVL2L-V3-10-RN.pdf
