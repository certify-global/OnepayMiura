Part No:		M000-EMVL2K-V3-4
Description:	Miura EMV Level 2 Kernel
Date:			2019-04-03


For more information please see release note: M000-EMVL2K-V3-4-RN.pdf
