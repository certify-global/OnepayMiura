Part No:		M000-EMVL2EP-V1-18
Description:	Miura Contactless Entry Point library
Date:			2021-02-18

For more information please see release note: M000-EMVL2EP-V1-18-RN.pdf

