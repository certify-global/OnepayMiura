Part No:		M000-EMVL2K4-V1-7
Description:	Miura Contactless AmEx ExpressPay library
Date:			2020-03-09

For more information please see release note: M000-EMVL2K4-V1-7-RN.pdf

