Part No:		M000-EMVL2K6-V1-2
Description:	Miura D-PAS Contactless Level 2 Kernel
Date:			2018-10-11

For more information please see release note: M000-EMVL2K6-V1-2-RN.pdf

