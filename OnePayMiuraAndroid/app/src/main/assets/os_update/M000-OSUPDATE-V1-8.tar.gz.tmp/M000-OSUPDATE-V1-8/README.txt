Part No:         M000-*OSUPDATE-V1-8
Title:           Miura OS Upgrade Script
Release Date:    2019-01-02

Description:
This is an upgrade package which will upgrade a Miura Operating System.

Installation:
This item has been tested on and signed to run on Miura M000 OS from V7-0 onwards,
with or without any version of MPI installed.

a) MSD installation:
    1. Copy this archive to the PED;
    2. Copy the OS archive to the MSD;
    3. Eject the MSD;
    4. Unplug the MSD.

b) Via MPI Protocol:
    1. Copy this archive to the PED;
    2. Copy the OS archive to the PED;
    3. Call Reset Device, P1==1.

Notes :
-------
1) If the upgrade takes place from MSD and there is no MPI installed, the PED
does not reboot automatically; this behaviour is used in the Production factory;
2) If there is an application installed, the 'Installing ...' messages are not
displayed on the PEDs screen during the OS install process.
