Part No:		M000-EMVL2K3-V1-3
Description:	Miura VISA Contactless Level 2 kernel
Date:			2016-01-26

For more information please see release note: M000-EMVL2K3-V1-3-RN.pdf

