Part No: 	M000-EMVL2K6-V1-0
Title:		Miura D-PAS Contactless Level 2 Kernel
Release Date:	2015-03-31


See Release note M000-EMVL2K6-V1-0-RN.pdf for more details.
