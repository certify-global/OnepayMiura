Part No:		M000-EMVL2L-V3-9
Description:	Miura EMV Level 2 support library
Date:			2019-04-02

For more information please see release note: M000-EMVL2L-V3-9-RN.pdf
