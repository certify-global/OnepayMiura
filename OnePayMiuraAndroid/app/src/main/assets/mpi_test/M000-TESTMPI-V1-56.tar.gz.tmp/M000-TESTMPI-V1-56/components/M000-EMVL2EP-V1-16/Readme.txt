Part No:		M000-EMVL2EP-V1-16
Description:	Miura Contactless Entry Point library
Date:			2019-04-11

For more information please see release note: M000-EMVL2EP-V1-16-RN.pdf

