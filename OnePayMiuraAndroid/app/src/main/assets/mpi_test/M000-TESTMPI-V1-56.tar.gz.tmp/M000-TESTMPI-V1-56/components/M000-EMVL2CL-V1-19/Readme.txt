Part No:		M000-EMVL2CL-V1-19
Description:	Miura Contactless support library
Date:			2019-04-11

For more information please see release note: M000-EMVL2CL-V1-19-RN.pdf

